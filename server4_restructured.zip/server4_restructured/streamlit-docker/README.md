# Streamlit Observability Console

Local development only — no Docker required.

## Run

```bash
cd streamlit-docker
python -m venv .venv

# Windows
.venv\Scripts\activate

# Mac / Linux
source .venv/bin/activate

pip install -r requirements.txt
streamlit run app.py
```

Opens at: http://localhost:8501
